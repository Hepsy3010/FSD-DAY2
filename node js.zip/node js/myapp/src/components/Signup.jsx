import { Button, TextField, Typography } from '@mui/material'
import React from 'react'

const Signup = () => {
  return (
    <div>
        <Typography variant='h4' >sign up</Typography>
        <br /><br />
        <TextField variant='outlined'label='Name'/>
        <br /><br />
        <TextField variant='outlined' label='place'/>
        <br /><br />
        <TextField variant='outlined' label='Age'/>
        <br /><br />
        <TextField variant='outlined'label='Gender'/>
        <br /><br />
        <TextField variant='outlined' label='Email'/>
        <br /><br />
        <TextField variant='outlined' label='Password'type='password'/>
        <br /><br />
        <Button variant='contained'>Submit</Button>
        
    </div>
  )
}

export default Signup