import React, { useState } from 'react'

const Mapping = () => {
    var[names,setNames]=useState(["achu","aksa","akku","ali"])
    
  return (
   <div>
<ul> 
    {names.map((value,index)=>{
        return(
        <li>{value}</li>

    )
    })}
   
</ul>
    </div>
  )
}

export default Mapping